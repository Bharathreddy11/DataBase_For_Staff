
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
public class Coursedetails{
 
	public static boolean checkcid(int cid){
		boolean status=false;
		try{
			Connection con=DB.getConnection();
			PreparedStatement ps=con.prepareStatement("select * from courses where cid=?");
			ps.setInt(1,cid);
		    ResultSet rs=ps.executeQuery();
			status=rs.next();
			con.close();
		}catch(Exception e){System.out.println(e);}
		return status;
	}
	public static int insertcourse(int cid,String cname,String cduration){
		int status=0;
		try{
			Connection con=DB.getConnection();
			PreparedStatement ps=con.prepareStatement("insert into Courses(Cid,Cname,Cduration) values(?,?,?)");
			ps.setInt(1,cid);
			ps.setString(2,cname);
			ps.setString(3,cduration);
			//ps.setString(4,femail);
			status=ps.executeUpdate();
			con.close();
		}catch(Exception e){System.out.println(e);}
		return status;
	}
	public static int deletecourse(int id){
		int status=0;
		try{
			Connection con=DB.getConnection();
			PreparedStatement ps=con.prepareStatement("delete from courses where cid=?");
			ps.setInt(1,id);
			status=ps.executeUpdate();
			con.close();
		}catch(Exception e){System.out.println(e);}
		return status;
	}
}
