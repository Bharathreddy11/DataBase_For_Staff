
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
public class Facultydetails{
 
	public static boolean checkfid(int fid){
		boolean status=false;
		try{
			Connection con=DB.getConnection();
			PreparedStatement ps=con.prepareStatement("select * from faculty where fid=?");
			ps.setInt(1,fid);
		    ResultSet rs=ps.executeQuery();
			status=rs.next();
			con.close();
		}catch(Exception e){System.out.println(e);}
		return status;
	}
	public static int insertfaculty(int fid,String fname,String fdesig,String femail){
		int status=0;
		try{
			Connection con=DB.getConnection();
			PreparedStatement ps=con.prepareStatement("insert into Faculty(Fid,Fname,Fdesig,Femail) values(?,?,?,?)");
			ps.setInt(1,fid);
			ps.setString(2,fname);
			ps.setString(3,fdesig);
			ps.setString(4,femail);
			status=ps.executeUpdate();
			con.close();
		}catch(Exception e){System.out.println(e);}
		return status;
	}
	public static int deletefaculty(int id){
		int status=0;
		try{
			Connection con=DB.getConnection();
			PreparedStatement ps=con.prepareStatement("delete from faculty where fid=?");
			ps.setInt(1,id);
			status=ps.executeUpdate();
			con.close();
		}catch(Exception e){System.out.println(e);}
		return status;
	}
}
