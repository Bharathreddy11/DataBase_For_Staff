
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
public class Statusdetails{
 
	public static boolean checkfid(int fid){
		boolean status=false;
		try{
			Connection con=DB.getConnection();
			PreparedStatement ps=con.prepareStatement("select * from enroll where fid=?");
			ps.setInt(1,fid);
		    ResultSet rs=ps.executeQuery();
			status=rs.next();
			con.close();
		}catch(Exception e){System.out.println(e);}
		return status;
	}
	public static int insertstatus(int fid,int fname,String fdesig){
		int status=0;
		try{
			Connection con=DB.getConnection();
			PreparedStatement ps=con.prepareStatement("insert into Enroll(fid,cid,status) values(?,?,?)");
			ps.setInt(1,fid);
			ps.setInt(2,fname);
			ps.setString(3,fdesig);
			//ps.setString(4,femail);
			status=ps.executeUpdate();
			con.close();
		}catch(Exception e){System.out.println(e);}
		return status;
	}
	public static int deletestatus(int id){
		int status=0;
		try{
			Connection con=DB.getConnection();
			PreparedStatement ps=con.prepareStatement("delete from enroll where fid=?");
			ps.setInt(1,id);
			status=ps.executeUpdate();
			con.close();
		}catch(Exception e){System.out.println(e);}
		return status;
	}
}
